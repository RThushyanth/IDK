package codechicken.core.gui;

public interface IGuiActionListener {

    public void actionPerformed(String actionCommand, Object... params);
}
